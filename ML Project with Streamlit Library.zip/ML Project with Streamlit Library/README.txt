Bu proje Streamlit ve Scikit-learn kütüphaneleriyle oluşturulmuş, interaktif bir web uygulamasıdır.
Göğüs kanseri veri setininin farklı sınıflandırma modelleriyle en iyi kesinlik sonuçlarını vermeyi hedeflemektedir.

Projenin kullanılabilmesi için kurulması gereken kütüphaneler:

pip install streamlit 
pip install scikit-learn
pip install matplotlib
pip install pandas 
pip install numpy
pip install seaborn
pip install Image

Proje main.py dosyası üzerinden kurulmaktadır. main.py dosyasında app.py dosyasındaki App sınıfından obje oluşturulmaktadır.

Terminale:

python -m streamlit run main.py    

veya 

streamlit run main.py 

yazarak çalıştırabilirsiniz. 

Sayfa açıldıktan sonra veriyi bilgisayarınızdan yüklemeniz, ve classifier seçimi yapmanız gerekmektedir.
Yüklediğiniz veri .csv formatında olmalıdır.

ÖNEMLİ:
Farklı bir bilgisayarda projeyi kurduğumda ve veriyi yüklemek istediğimde "Axios Error: Request failed with status code 403"
hatası aldım . Bu hatayı çözmek için proje dosyasının içnde .streamlit klaösrü bulunmaktadır. Bu klasörün içinde config.toml
dosyası bulunmaktadır. Bu hatayla karşılaşılmaması içn bu klasörü ekledim. 



